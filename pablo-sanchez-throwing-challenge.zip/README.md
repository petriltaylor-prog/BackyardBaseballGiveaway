# Pablo Sanchez Throwing Challenge

This is the simple self-contained event table website.

Open:

```text
outputs/index.html
```

No accounts, keys, or setup are required.

The app saves participants in the browser on the device running the event table. It includes:

- Participant entry form
- Automatic raffle entries equal to score
- Dashboard with search, edit, CSV export, and reset
- Weighted raffle wheel
- Winner details page
- Mobile-friendly Backyard Baseball themed design
